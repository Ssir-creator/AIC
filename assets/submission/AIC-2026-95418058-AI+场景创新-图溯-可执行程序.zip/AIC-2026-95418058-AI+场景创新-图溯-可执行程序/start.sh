#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
chmod +x tusu
exec ./tusu --host 127.0.0.1 --port 8765
