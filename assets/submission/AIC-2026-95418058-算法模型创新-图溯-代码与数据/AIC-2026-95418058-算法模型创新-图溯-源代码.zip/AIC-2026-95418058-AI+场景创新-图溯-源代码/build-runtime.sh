#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python -m pip install pyinstaller==6.22.3
python -m PyInstaller --noconfirm --clean --onefile --name tusu --paths . --exclude-module tkinter --exclude-module torch --exclude-module diffusers --exclude-module transformers --exclude-module trustmark tusu_launcher.py
# Copy dist/tusu beside assets/, model_worker.py and config.example.json.
