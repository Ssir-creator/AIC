#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements-core.txt
exec .venv/bin/python app.py --host 127.0.0.1 --port 8765
