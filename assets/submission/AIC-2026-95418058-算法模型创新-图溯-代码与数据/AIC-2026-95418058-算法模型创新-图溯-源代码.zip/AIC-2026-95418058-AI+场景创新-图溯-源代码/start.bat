@echo off
cd /d "%~dp0"
python -m venv .venv
if errorlevel 1 goto failed
.venv\Scripts\python.exe -m pip install -r requirements-core.txt
if errorlevel 1 goto failed
.venv\Scripts\python.exe app.py --host 127.0.0.1 --port 8765
pause
exit /b
:failed
echo Setup failed. Check Python 3.11+ and network connection.
pause
