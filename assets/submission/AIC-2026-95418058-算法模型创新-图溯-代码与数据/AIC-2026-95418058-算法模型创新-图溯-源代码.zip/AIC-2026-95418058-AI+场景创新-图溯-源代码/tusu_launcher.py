"""Frozen local launcher. Model inference uses separately configured Python envs."""
import argparse
from pathlib import Path
import sys
import app

def main():
    root=Path(sys.executable).resolve().parent if getattr(sys,'frozen',False) else Path(__file__).resolve().parent
    app.ROOT=root
    app.DATA=root/'data'
    app.DATA.mkdir(exist_ok=True)
    parser=argparse.ArgumentParser(description='图溯本地服务')
    parser.add_argument('--host',default='127.0.0.1')
    parser.add_argument('--port',type=int,default=8765)
    args=parser.parse_args()
    print(f'图溯 {app.VERSION}：http://127.0.0.1:{args.port}',flush=True)
    print('首次使用请在浏览器创建工作空间。Ctrl+C停止服务。',flush=True)
    app.ThreadingHTTPServer((args.host,args.port),app.Handler).serve_forever()

if __name__=='__main__': main()
